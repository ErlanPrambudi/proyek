# shoes > 2023-11-30 10:41pm
https://universe.roboflow.com/universitas-teknologi-digital-indonesia/shoes-jzi0l

Provided by a Roboflow user
License: CC BY 4.0

